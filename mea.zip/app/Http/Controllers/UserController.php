<?php

namespace App\Http\Controllers;

use App\User;
use Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Auth;
use DB;
use App\Helpers\Helper;
use Illuminate\Support\Facades\Validator;
use Session;
use Carbon\Carbon;
use stdClass;



class UserController extends Controller
{
    /**
     * Store a newly created and updated dancer profile.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function updateProfile(Request $request)
    {
        // echo "<pre>"; print_r($request->all()); exit;
        $user = Auth::user();
        $responseData = array();
        $responseData['status'] = 0;
        $responseData['message'] = '';
        $responseData['errors'] = array();
        $responseData['data'] = [];
        DB::beginTransaction();
        try{
            $dob = Carbon::createFromFormat('d/m/Y', $request->dob)->format('Y-m-d');
            // $request['dob'] =  date('Y-m-d', strtotime($request->dob));
            $validationArray = [
                // 'name' => 'required|min:2|max:255',
                // 'nick_name' => 'required|min:2|max:255',
                // 'expertise' => 'required',
                // 'gender' => 'required',
                // 'dob' => 'required',
                // 'phone' => 'required', 'max:15',
                // 'danceMusicTypes' => 'required',
                // 'fb_link' => 'nullable',
                // 'web_link' => 'nullable',
                // 'country' => 'required',
                // 'city' => 'required',
            ];
            // if(Auth::user()->is_profile_filled != 1){
            //     $validationSettingArray = [
            //         'bank_account_number' => 'required|max:40|min:6',
            //         'bank_name' => 'required|max:100',
            //         'bank_ifsc_code' => 'required|max:12',
            //         'bank_country' => 'required|max:100',
            //     ];
            //     $validationArray = array_merge($validationArray, $validationSettingArray);
            // }

            $validator = Validator::make($request->all(), $validationArray);
            if ($validator->fails()) {
                DB::rollback();
                $responseData['message'] = $validator->errors()->first();
                $responseData['errors'] = $validator->errors()->toArray();
                return $this->commonResponse($responseData, 200);
            } else {                

                /*
                 * Profile image upload also check for old uploaded image
                 */
                $file = $logo_name = "";
                if($request->file('profile_image') != ''){
                    $file = $request->file('profile_image');                    
                    $ext = $file->getClientOriginalName();
                    $logo_name = uniqid('profile_', true) . time() . '.' . $ext;
                } else {
                    $logo_name = $request->old_logo;
                }

                $coverfile = $cover_name = "";
                if($request->file('cover') != ''){
                    $coverfile = $request->file('cover');                    
                    $ext = $coverfile->getClientOriginalName();
                    $cover_name = uniqid('cover_', true) . time() . '.' . $ext;
                } else {
                    $cover_name = $request->old_cover;
                }
                
                $cvfile = $cv_name = "";
                if($request->file('resume') != ''){
                    $cvfile = $request->file('resume');                    
                    $ext = $cvfile->getClientOriginalName();
                    $cv_name = uniqid('resume_', true) . time() . '.' . $ext;
                } else {
                    $cv_name = $request->old_resume;
                }

                $user = Auth::user();
                $user->name = $request->name;
                $user->logo = $logo_name;
                $user->is_profile_filled = 1;
                $user->save();

                /*
                 * Profile image upload also check for old uploaded image
                 */
                if($request->hasFile('profile_image')){
                    Helper::uploaddynamicFile(config('constant.profile_url'), $logo_name, $file);
                    if(isset($request->old_profile_image)){
                        Helper::checkFileExists(config('constant.profile_url') . $request->old_profile_image, true, true);
                    }
                }

                if($request->hasFile('cover')){
                    Helper::uploaddynamicFile(config('constant.profile_cover_url'), $cover_name, $coverfile);
                    if(isset($request->old_cover)){
                        Helper::checkFileExists(config('constant.profile_cover_url') . $request->old_cover, true, true);
                    }
                }
                
                if($request->hasFile('resume')){
                    Helper::uploaddynamicFile(config('constant.resume_url'), $cv_name, $cvfile);
                    if(isset($request->old_resume)){
                        Helper::checkFileExists(config('constant.resume_url') . $request->old_resume, true, true);
                    }
                }

                $is_experience = 0;
                /*
                 * save user profile data
                 */
                $user->userProfile()->updateOrCreate(
                    ['user_id' => Auth::user()->id],[
                    "dob" => $dob,
                    "cover" => $cover_name,
                    "resume" => $cv_name,
                    "phone" => $request->phone,
                    "gender" => $request->gender,
                    'description' => $request->about,
                    'fb_link' => $request->fb_link,
                    'insta_link' => $request->insta_link,
                    'tw_link' => $request->tw_link,
                    'web_link' => $request->web_link,
                    'city' => $request->city,                    
                    'is_experience' => $is_experience,                    
                ]);

                /*
                 * save user interest data
                 */
                if(!empty($request->interests)){
                    $user->interests()->delete();
                    $interest_explode = explode(', ', $request->interests);

                    foreach ($interest_explode as $key => $interest) {
                        $userInterests[] = ['user_id' => Auth::user()->id,'user_profile_id' => $user->userProfile->id, 'title' => $interest, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')];
                    }

                    $user->interests()->insert($userInterests);
                }

                /*
                 * save user skills data
                 */
                if(!empty($request->skills)){
                    $user->skills()->delete();
                    $interest_explode = explode(', ', $request->skills);

                    foreach ($interest_explode as $key => $skill) {
                        $userSkills[] = ['user_id' => Auth::user()->id,'user_profile_id' => $user->userProfile->id, 'title' => $skill, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')];
                    }

                    $user->skills()->insert($userSkills);
                }
                
                /*
                 * save user answers data
                 */
                if(!empty($request->ans)){
                    $user->answers()->delete();
                    foreach ($request->ans as $key => $answer) {
                        $userAnswers[] = ['user_id' => Auth::user()->id,'user_profile_id' => $user->userProfile->id, 'question_id' => $key, 'title' => $answer, 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')];
                    }

                    $user->answers()->insert($userAnswers);
                }
                
                DB::commit();
                $responseData['status'] = 1;
                $responseData['redirect'] = route('user.view-profile',['slug' => $user->slug]);
                $responseData['message'] = trans('page.Profile_saved_successfully');
                Session::flash('success', $responseData['message']);
                return $this->commonResponse($responseData, 200);
            }

        } catch(Exception $e){
            Log::emergency('Professional profile save Exception:: Message:: '.$e->getMessage().' line:: '.$e->getLine().' Code:: '.$e->getCode().' file:: '.$e->getFile());
            DB::rollback();
            $code = ($e->getCode() != '')?$e->getCode():500;
            $responseData['message'] = trans('common.something_went_wrong');
            return $this->commonResponse($responseData, $code);
        }
    }
}
