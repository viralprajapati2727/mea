@component('mail::message')

{!! $content['body'] !!}

@endcomponent