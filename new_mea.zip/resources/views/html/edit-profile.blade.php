@extends('layouts.app')
@section('content')
<div class="page-main">
    <div class="edit-profile-wraper">
        <div class="container">
            <div class="title">
                <h2>Profile</h2>
            </div>
            <form>
            <div class="form-group">
                <label for="name" class="col-form-label">Name</label>
                <input type="text" class="form-control" id="name">
            </form>
        </div>
    </div>
</div>
@endsection