<?php

return [

    'about_us' => 'About us',
    'blog' => 'Blog',
    'login' => 'Login',
    'SignIn' => 'Sign In',
    'menu' => 'Menu',
    'my_profile' => 'My Profile',
    'Profile' => 'Profile',
    'messages' => 'Messages',
    'account_settings' => 'Account Settings',
    'log_out' => 'Logout',
    'forgot_password' => 'Forgot Password?',
    'Remember_Me' => 'Remember me',
    'New_User' => 'New User?',
    'payment_history' => 'Payment History',

    // Footer
];
