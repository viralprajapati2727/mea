<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserSkill extends Model
{
    protected $guarded = [];

    protected $hidden = ['created_at','updated_at'];
}
